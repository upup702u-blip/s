const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "../../data");
const SCORE_FILE = path.join(DATA_DIR, "leaderboard.json");

let scores = {};
try {
  const raw = fs.readFileSync(SCORE_FILE, "utf8");
  scores = JSON.parse(raw);
} catch (e) {
  scores = {};
}

function saveScores() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(SCORE_FILE, JSON.stringify(scores, null, 2), "utf8");
  } catch (e) {
    console.error("خطأ في حفظ ملف الصدارة:", e);
  }
}

function addScore(userId, points) {
  if (!scores[userId]) scores[userId] = 0;
  scores[userId] += points;
  saveScores();
}

function getLeaderboardText() {
  const entries = Object.entries(scores);
  if (entries.length === 0) return "لا يوجد أي نقاط حتى الآن.";

  entries.sort((a, b) => b[1] - a[1]);
  return entries
    .map(([id, pts], i) => `**${i + 1}.** <@${id}> — ${pts} نقطة`)
    .join("\n");
}

function clearLeaderboard() {
  for (const key of Object.keys(scores)) {
    delete scores[key];
  }
  saveScores();
}

module.exports = {
  scores,
  addScore,
  getLeaderboardText,
  clearLeaderboard,
};