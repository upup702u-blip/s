const {
  EmbedBuilder,
  PermissionFlagsBits,
  ButtonBuilder,
  ActionRowBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");
const GameState = require("./GameState");
const { generateBoard, buildBoardComponents, buildBoardEmbed } = require("./board");
const { addScore } = require("./leaderboard");
const { config } = require("../config");

const games = new Map(); // channelId -> GameState

function getGame(channelId) {
  return games.get(channelId) || null;
}

function createGame(channel) {
  const game = new GameState(channel, config);
  games.set(channel.id, game);
  return game;
}

function deleteGame(channelId) {
  const game = games.get(channelId);
  if (game) game.clearAllTimeouts();
  games.delete(channelId);
}

// ========== LOBBY ==========

function buildLobbyEmbed(game, remainingSec) {
  const bluePlayers = game.blueTeam.size;
  const redPlayers = game.redTeam.size;
  const blueLeader = game.blueLeader ? 1 : 0;
  const redLeader = game.redLeader ? 1 : 0;

  return new EmbedBuilder()
    .setTitle("🎮 كودنيمز - اللوبي")
    .setDescription(
      "اضغط على الأزرار للدخول إلى الفرق.\n" +
        "مو لازم يكتمل العدد، يكفي يكون في كل فريق قائد.\n\n" +
        `⏱ الوقت المتبقي لبدء اللعبة تلقائيًا: **${remainingSec}** ثانية`
    )
    .addFields(
      {
        name: "🔵 فريق الأزرق",
        value: `القادة: ${blueLeader}/1\nعدد اللاعبين: ${bluePlayers}`,
        inline: true,
      },
      {
        name: "🔴 فريق الأحمر",
        value: `القادة: ${redLeader}/1\nعدد اللاعبين: ${redPlayers}`,
        inline: true,
      }
    )
    .setColor(0x3498db);
}

function buildLobbyComponents() {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("join_blue_leader")
        .setLabel("قائد الأزرق")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("join_blue_player")
        .setLabel("فريق الأزرق")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("join_red_leader")
        .setLabel("قائد الأحمر")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("join_red_player")
        .setLabel("فريق الأحمر")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("leave_game")
        .setLabel("خروج من اللعبة")
        .setStyle(ButtonStyle.Secondary)
    ),
  ];
}

async function startLobby(message) {
  const channel = message.channel;

  const existing = getGame(channel.id);
  if (existing && existing.stage !== "ENDED") {
    return message.reply("هناك لعبة قيد التشغيل بالفعل في هذا الشات.");
  }

  const game = createGame(channel);

  const embed = buildLobbyEmbed(game, config.lobbyTimeSec);
  const msg = await channel.send({
    embeds: [embed],
    components: buildLobbyComponents(),
  });

  game.lobbyMessage = msg;

  let remaining = config.lobbyTimeSec;

  game.lobbyInterval = setInterval(async () => {
    if (!game.lobbyMessage || game.stage !== "LOBBY") return;
    remaining -= 5;
    if (remaining < 0) remaining = 0;
    try {
      await game.lobbyMessage.edit({
        embeds: [buildLobbyEmbed(game, remaining)],
        components: buildLobbyComponents(),
      });
    } catch (e) {}
  }, 5000);

  game.lobbyTimeout = setTimeout(() => {
    startGameIfReady(game);
  }, config.lobbyTimeSec * 1000);
}

async function handleLobbyButton(interaction) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "LOBBY") {
    return interaction.reply({ content: "اللوبي غير نشط.", ephemeral: true });
  }

  const userId = interaction.user.id;
  const id = interaction.customId;

  if (id === "leave_game") {
    game.blueTeam.delete(userId);
    game.redTeam.delete(userId);
    if (game.blueLeader === userId) game.blueLeader = null;
    if (game.redLeader === userId) game.redLeader = null;
    return interaction.reply({ content: "تم خروجك من اللعبة.", ephemeral: true });
  }

  if (id === "join_blue_leader") {
    if (game.blueLeader && game.blueLeader !== userId) {
      return interaction.reply({
        content: "يوجد بالفعل قائد لفريق الأزرق.",
        ephemeral: true,
      });
    }
    game.blueLeader = userId;
    game.blueTeam.add(userId);
    game.redTeam.delete(userId);
    if (game.redLeader === userId) game.redLeader = null;
    await interaction.reply({ content: "أصبحت قائد فريق الأزرق.", ephemeral: true });
  } else if (id === "join_red_leader") {
    if (game.redLeader && game.redLeader !== userId) {
      return interaction.reply({
        content: "يوجد بالفعل قائد لفريق الأحمر.",
        ephemeral: true,
      });
    }
    game.redLeader = userId;
    game.redTeam.add(userId);
    game.blueTeam.delete(userId);
    if (game.blueLeader === userId) game.blueLeader = null;
    await interaction.reply({ content: "أصبحت قائد فريق الأحمر.", ephemeral: true });
  } else if (id === "join_blue_player") {
    game.blueTeam.add(userId);
    game.redTeam.delete(userId);
    await interaction.reply({ content: "انضممت لفريق الأزرق.", ephemeral: true });
  } else if (id === "join_red_player") {
    game.redTeam.add(userId);
    game.blueTeam.delete(userId);
    await interaction.reply({ content: "انضممت لفريق الأحمر.", ephemeral: true });
  }

  if (game.lobbyMessage) {
    try {
      await game.lobbyMessage.edit({
        embeds: [buildLobbyEmbed(game, Math.max(0, config.lobbyTimeSec))],
        components: buildLobbyComponents(),
      });
    } catch (e) {}
  }
}

async function startGameIfReady(game) {
  if (game.stage !== "LOBBY") return;

  game.clearAllTimeouts();

  if (!game.blueLeader || !game.redLeader) {
    game.end();
    deleteGame(game.channel.id);
    await game.channel.send("ما تم تعيين قائد لكل فريق، تم إلغاء اللعبة.");
    return;
  }

  game.stage = "IN_PROGRESS";

  await lockChannelForGame(game);

  game.boardWords = generateBoard();
  const deadly = game.boardWords.find((w) => w.type === "DEADLY");
  game.deadlyWordId = deadly ? deadly.id : null;
  game.neutralIds = new Set(
    game.boardWords.filter((w) => w.type === "NEUTRAL").map((w) => w.id)
  );

  game.currentTurn = Math.random() < 0.5 ? "BLUE" : "RED";

  const msg = await game.channel.send({
    embeds: [buildBoardEmbed(game)],
    components: buildBoardComponents(game),
  });

  game.boardMessage = msg;

  await startNewTurn(game);
}

async function lockChannelForGame(game) {
  const channel = game.channel;
  const guild = channel.guild;
  const everyone = guild.roles.everyone;

  game.originalEveryoneOverwrite = channel.permissionOverwrites.cache.get(
    everyone.id
  );

  await channel.permissionOverwrites.edit(everyone, {
    SendMessages: false,
  });

  if (game.blueLeader) {
    await channel.permissionOverwrites.edit(game.blueLeader, {
      SendMessages: true,
    });
  }
  if (game.redLeader) {
    await channel.permissionOverwrites.edit(game.redLeader, {
      SendMessages: true,
    });
  }
}

async function restoreChannelPermissions(game) {
  const channel = game.channel;
  const guild = channel.guild;
  const everyone = guild.roles.everyone;

  if (game.originalEveryoneOverwrite) {
    const allow = game.originalEveryoneOverwrite.allow;
    await channel.permissionOverwrites.edit(everyone, {
      SendMessages: allow.has(PermissionFlagsBits.SendMessages),
    });
  } else {
    await channel.permissionOverwrites.delete(everyone).catch(() => {});
  }

  if (game.blueLeader) {
    await channel.permissionOverwrites.delete(game.blueLeader).catch(() => {});
  }
  if (game.redLeader) {
    await channel.permissionOverwrites.delete(game.redLeader).catch(() => {});
  }
}

// ========== HINT & TURN MANAGEMENT ==========

function getTeamWordsText(game, team) {
  const words = game.boardWords.filter((w) => w.type === team);
  return words
    .map((w) => `${w.label}${w.chosenBy ? " ✅" : ""}`)
    .join("، ");
}

async function sendLeaderEphemeral(interaction, game, team) {
  const userId = interaction.user.id;
  if (team === "BLUE" && game.blueLeader !== userId) {
    return interaction.reply({
      content: "هذا الزر مخصص لقائد فريق الأزرق.",
      ephemeral: true,
    });
  }
  if (team === "RED" && game.redLeader !== userId) {
    return interaction.reply({
      content: "هذا الزر مخصص لقائد فريق الأحمر.",
      ephemeral: true,
    });
  }

  const text = getTeamWordsText(game, team);
  const seconds = game.config.hintTimeSec || 80;

  const hintRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`open_hint_${team}`)
      .setLabel("🧠 تلميح")
      .setStyle(ButtonStyle.Primary)
  );

  return interaction.reply({
    content:
      `هذه كلمات فريقك ${
        team === "BLUE" ? "🔵 الأزرق" : "🔴 الأحمر"
      }:\n${text}\n\n` +
      `⏱ لديك تقريبًا **${seconds} ثانية** من بداية دور فريقك لإرسال التلميح قبل ما ينتهي الدور.\n\n` +
      "عشان ترسل التلميح:\n" +
      "1. اضغط زر **🧠 تلميح** تحت.\n" +
      "2. في النافذة (Modal) اكتب:\n" +
      "   • التلميح (كلمة واحدة فقط)\n" +
      "   • عدد الكلمات المسموح لفريقك يختارها في هذه الجولة (من 1 إلى 5)",
    components: [hintRow],
    ephemeral: true,
  });
}

async function handleViewTeamWords(interaction, team) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "IN_PROGRESS") {
    return interaction.reply({
      content: "لا توجد لعبة نشطة حالياً.",
      ephemeral: true,
    });
  }
  return sendLeaderEphemeral(interaction, game, team);
}

async function openHintModal(interaction, team) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "IN_PROGRESS") {
    return interaction.reply({
      content: "لا توجد لعبة نشطة حالياً.",
      ephemeral: true,
    });
  }

  const userId = interaction.user.id;
  if (team === "BLUE" && game.blueLeader !== userId) {
    return interaction.reply({
      content: "هذا الزر مخصص لقائد فريق الأزرق.",
      ephemeral: true,
    });
  }
  if (team === "RED" && game.redLeader !== userId) {
    return interaction.reply({
      content: "هذا الزر مخصص لقائد فريق الأحمر.",
      ephemeral: true,
    });
  }

  if (!game.hintState || game.hintState.phase !== "AWAIT_HINT") {
    return interaction.reply({
      content: "لا يمكنك إرسال التلميح الآن. انتظر بداية دور فريقك.",
      ephemeral: true,
    });
  }

  if (game.hintState.team !== team) {
    return interaction.reply({
      content: "ليس دور فريقك حالياً.",
      ephemeral: true,
    });
  }

  const modal = new ModalBuilder()
    .setCustomId(`hint_modal_${team}`)
    .setTitle("إرسال التلميح");

  const hintInput = new TextInputBuilder()
    .setCustomId("hint_word")
    .setLabel("اكتب التلميح (كلمة واحدة فقط)")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const countInput = new TextInputBuilder()
    .setCustomId("hint_count")
    .setLabel("اكتب عدد الكلمات المسموح بها (1 - 5)")
    .setStyle(TextInputStyle.Short)
    .setRequired(true);

  const row1 = new ActionRowBuilder().addComponents(hintInput);
  const row2 = new ActionRowBuilder().addComponents(countInput);

  modal.addComponents(row1, row2);

  return interaction.showModal(modal);
}

async function handleHintModalSubmit(interaction) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "IN_PROGRESS") {
    return interaction.reply({
      content: "لا توجد لعبة نشطة حالياً.",
      ephemeral: true,
    });
  }

  const customId = interaction.customId;
  const parts = customId.split("_"); // hint_modal_BLUE
  const team = parts[2];

  if (!["BLUE", "RED"].includes(team)) {
    return interaction.reply({
      content: "خطأ في التعرف على الفريق.",
      ephemeral: true,
    });
  }

  const userId = interaction.user.id;
  if (team === "BLUE" && game.blueLeader !== userId) {
    return interaction.reply({
      content: "هذا المودال مخصص لقائد فريق الأزرق فقط.",
      ephemeral: true,
    });
  }
  if (team === "RED" && game.redLeader !== userId) {
    return interaction.reply({
      content: "هذا المودال مخصص لقائد فريق الأحمر فقط.",
      ephemeral: true,
    });
  }

  if (!game.hintState || game.hintState.phase !== "AWAIT_HINT") {
    return interaction.reply({
      content: "لا يمكنك إرسال التلميح الآن.",
      ephemeral: true,
    });
  }

  if (game.hintState.team !== team) {
    return interaction.reply({
      content: "ليس دور فريقك حالياً.",
      ephemeral: true,
    });
  }

  const word = interaction.fields.getTextInputValue("hint_word").trim();
  const countStr = interaction.fields.getTextInputValue("hint_count").trim();

  if (!word) {
    return interaction.reply({
      content: "التلميح لا يمكن أن يكون فارغاً.",
      ephemeral: true,
    });
  }

  if (word.split(/\s+/).length > 1) {
    return interaction.reply({
      content: "التلميح لازم يكون **كلمة واحدة فقط**. تم إلغاء التلميح.",
      ephemeral: true,
    });
  }

  const count = parseInt(countStr, 10);
  if (isNaN(count) || count < 1 || count > 5) {
    return interaction.reply({
      content: "عدد الكلمات لازم يكون رقم بين 1 و 5.",
      ephemeral: true,
    });
  }

  game.hintState.hintWord = word;
  game.hintState.guessCount = count;

  await finalizeHint(game);

  return interaction.reply({
    content:
      `تم تسجيل تلميحك: **${word}**\n` +
      `عدد الكلمات المسموح بها في هذه الجولة: **${count}**.`,
    ephemeral: true,
  });
}

async function startNewTurn(game, reasonMsg) {
  if (game.hintTimeout) clearTimeout(game.hintTimeout);
  if (game.guessTimeout) clearTimeout(game.guessTimeout);

  if (reasonMsg) {
    game.currentTurn = game.currentTurn === "BLUE" ? "RED" : "BLUE";
  }

  game.hintState = {
    phase: "AWAIT_HINT",
    team: game.currentTurn,
    hintWord: null,
    guessCount: null,
    usedGuesses: 0,
  };

  const teamName = game.currentTurn === "BLUE" ? "الأزرق" : "الأحمر";

  if (reasonMsg) {
    await game.channel.send(
      `${reasonMsg}\n\n♻️ الآن يبدأ دور فريق **${teamName}**. على القائد إرسال التلميح خلال ${config.hintTimeSec} ثانية.`
    );
  } else {
    await game.channel.send(
      `🔔 تم اختيار الفريق الذي يبدأ عشوائياً.\nالآن دور فريق **${teamName}**.\n` +
        `على القائد إرسال التلميح خلال **${config.hintTimeSec}** ثانية.`
    );
  }

  if (game.boardMessage) {
    await game.boardMessage.edit({
      embeds: [buildBoardEmbed(game)],
      components: buildBoardComponents(game),
    });
  }

  game.hintTimeout = setTimeout(() => {
    handleHintTimeout(game);
  }, config.hintTimeSec * 1000);
}

async function handleHintTimeout(game) {
  if (!game.hintState || game.hintState.phase !== "AWAIT_HINT") return;
  const teamName = game.hintState.team === "BLUE" ? "الأزرق" : "الأحمر";
  await game.channel.send(
    `⏰ انتهى وقت قائد فريق **${teamName}** لإرسال التلميح.\nينتقل الدور للفريق الآخر.`
  );
  await startNewTurn(game, "");
}

async function finalizeHint(game) {
  if (!game.hintState) return;
  if (
    !game.hintState.hintWord ||
    !game.hintState.guessCount ||
    game.hintState.phase !== "AWAIT_HINT"
  )
    return;

  if (game.hintTimeout) clearTimeout(game.hintTimeout);

  game.hintState.phase = "GUESSING";
  game.hintState.usedGuesses = 0;

  const teamName = game.hintState.team === "BLUE" ? "الأزرق" : "الأحمر";

  await game.channel.send(
    `🧠 تلميح فريق **${teamName}**: **${game.hintState.hintWord}**\n` +
      `مسموح لهم اختيار **${game.hintState.guessCount}** كلمة خلال **${config.guessTimeSec}** ثانية.`
  );

  game.guessTimeout = setTimeout(() => {
    handleGuessTimeout(game);
  }, config.guessTimeSec * 1000);
}

async function handleGuessTimeout(game) {
  if (!game.hintState || game.hintState.phase !== "GUESSING") return;
  const teamName = game.hintState.team === "BLUE" ? "الأزرق" : "الأحمر";
  await game.channel.send(
    `⏰ انتهى وقت إجابة فريق **${teamName}** لهذه الجولة.\nينتقل الدور للفريق الآخر.`
  );
  await startNewTurn(game, "");
}

// ========== WORD CLICKS ==========

async function handleWordClick(interaction) {
  const game = getGame(interaction.channel.id);
  if (!game || game.stage !== "IN_PROGRESS") {
    return interaction.reply({
      content: "لا توجد لعبة نشطة الآن.",
      ephemeral: true,
    });
  }

  const userId = interaction.user.id;
  let team = null;
  if (game.blueTeam.has(userId)) team = "BLUE";
  else if (game.redTeam.has(userId)) team = "RED";

  if (!team) {
    return interaction.reply({
      content: "أنت لست ضمن أي فريق في هذه اللعبة.",
      ephemeral: true,
    });
  }

  if (!game.hintState || game.hintState.phase !== "GUESSING") {
    return interaction.reply({
      content: "لا يمكنك اختيار الكلمات الآن، انتظر التلميح.",
      ephemeral: true,
    });
  }

  if (team !== game.currentTurn) {
    return interaction.reply({
      content: "ليس دور فريقك حالياً.",
      ephemeral: true,
    });
  }

  const wordId = interaction.customId.replace("word_", "");
  const wordObj = game.boardWords.find((w) => w.id === wordId);
  if (!wordObj || wordObj.chosenBy) {
    return interaction.reply({
      content: "هذه الكلمة تم اختيارها بالفعل.",
      ephemeral: true,
    });
  }

  wordObj.chosenBy = team;

  if (game.boardMessage) {
    await game.boardMessage.edit({
      embeds: [buildBoardEmbed(game)],
      components: buildBoardComponents(game),
    });
  }

  let msg = "";
  const teamName = team === "BLUE" ? "الأزرق" : "الأحمر";

  if (wordObj.type === "DEADLY") {
    const otherTeam = team === "BLUE" ? "RED" : "BLUE";
    const otherName = otherTeam === "BLUE" ? "الأزرق" : "الأحمر";
    msg =
      `💀 <@${userId}> اختار الكلمة المميتة (**${wordObj.label}**).\n` +
      `فريق **${teamName}** خسر مباشرة.\nالفائز: **${otherName}** 🎉`;

    await interaction.reply({ content: "الكلمة المميتة!", ephemeral: true });
    return endGame(game, otherTeam, msg);
  }

  if (wordObj.type === team) {
    if (team === "BLUE") game.blueScore++;
    else game.redScore++;
    msg = `✅ <@${userId}> اختار كلمة صحيحة لفريق **${teamName}** (**${wordObj.label}**).`;
  } else if (wordObj.type === "NEUTRAL") {
    msg = `🟡 <@${userId}> اختار كلمة محايدة (**${wordObj.label}**). ينتهي الدور.`;
    await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
    return startNewTurn(game, msg);
  } else {
    msg =
      `❌ <@${userId}> اختار كلمة تخص الفريق الآخر (**${wordObj.label}**).\n` +
      "ينتهي دور فريقه.";
    await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
    return startNewTurn(game, msg);
  }

  if (game.blueScore >= game.config.targetScore || game.redScore >= game.config.targetScore) {
    const winner = game.blueScore >= game.config.targetScore ? "BLUE" : "RED";
    const winnerName = winner === "BLUE" ? "الأزرق" : "الأحمر";
    msg += `\n\n🏆 فريق **${winnerName}** خلص كل كلماته وفاز!`;
    await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
    return endGame(game, winner, msg);
  }

  if (game.hintState && game.hintState.team === team) {
    game.hintState.usedGuesses++;
    if (game.hintState.usedGuesses >= game.hintState.guessCount) {
      msg += `\n🔚 انتهت المحاولات لهذه الجولة لفريق **${teamName}**.`;
      await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
      return startNewTurn(game, msg);
    }
  }

  await interaction.reply({ content: "تم تسجيل اختيارك.", ephemeral: true });
  await game.channel.send(msg);
}

// ========== END GAME & BOARD VIEW ==========

async function endGame(game, winnerTeam, extraMsg) {
  game.end();
  await restoreChannelPermissions(game);
  deleteGame(game.channel.id);

  if (!winnerTeam) {
    if (extraMsg) await game.channel.send(extraMsg);
    return;
  }

  const winnerName = winnerTeam === "BLUE" ? "الأزرق" : "الأحمر";
  let msg = extraMsg || "";
  msg += `\n\n🎉 فريق **${winnerName}** هو الفائز في هذه اللعبة!`;

  const winners = winnerTeam === "BLUE" ? game.blueTeam : game.redTeam;
  const leaderId = winnerTeam === "BLUE" ? game.blueLeader : game.redLeader;

  if (leaderId) addScore(leaderId, 2);
  for (const id of winners) {
    if (id === leaderId) continue;
    addScore(id, 1);
  }

  await game.channel.send(msg);
}

async function showBoard(message) {
  const game = getGame(message.channel.id);
  if (!game || game.stage !== "IN_PROGRESS")
    return message.reply("لا توجد لعبة نشطة حالياً.");
  if (!game.boardMessage) return message.reply("لم يتم إنشاء البورد بعد.");
  return message.reply("هذه هي رسالة البورد الحالية 👇");
}

// اختياري: تركنا handleHintCommand كـ placeholder لو حبيت ترجع للأوامر النصية
async function handleHintCommand(message, args) {
  return message.reply("إرسال التلميح يتم الآن عبر زر (تلميح) ونافذة المودال فقط.");
}

module.exports = {
  getGame,
  startLobby,
  showBoard,
  handleHintCommand,
  handleLobbyButton,
  handleWordClick,
  handleViewTeamWords,
  openHintModal,
  handleHintModalSubmit,
};