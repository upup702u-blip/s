const { config, isOwner } = require("../config");
const { clearLeaderboard, addScore } = require("../game/leaderboard");

async function handleOwnerCommand(message, command, args, client) {
  if (!isOwner(message.author.id)) return;

  if (command === "botsetchannel") {
    config.allowedChannels = [message.channel.id];
    return message.reply("تم تعيين هذه القناة لتكون قناة اللعبة الوحيدة.");
  }

  if (command === "botaddowner") {
    const user = message.mentions.users.first();
    if (!user) return message.reply("منشن الشخص الذي تريد إضافته كأونر.");
    if (!config.owners.includes(user.id)) config.owners.push(user.id);
    return message.reply(`تمت إضافة <@${user.id}> كأونر للبوت.`);
  }

  if (command === "botname") {
    const name = args.join(" ");
    if (!name) return message.reply("اكتب الاسم الجديد.");
    try {
      await client.user.setUsername(name);
      return message.reply(`تم تغيير اسم البوت إلى **${name}**`);
    } catch (e) {
      console.error(e);
      return message.reply("تعذر تغيير اسم البوت.");
    }
  }

  if (command === "botavatar") {
    const att = message.attachments.first();
    if (!att) return message.reply("أرسل صورة مع الأمر.");
    try {
      await client.user.setAvatar(att.url);
      return message.reply("تم تغيير صورة البوت.");
    } catch (e) {
      console.error(e);
      return message.reply("تعذر تغيير صورة البوت.");
    }
  }

  if (command === "botstatus") {
    const text = args.join(" ");
    if (!text) return message.reply("اكتب الحالة.");
    client.user.setPresence({
      activities: [{ name: text }],
      status: "online",
    });
    return message.reply("تم تغيير حالة البوت.");
  }

  if (command === "cleartop") {
    clearLeaderboard();
    return message.reply("تم مسح قائمة الصدارة.");
  }

  if (command === "addpoints") {
    const user = message.mentions.users.first();
    const pts = parseInt(args[1], 10);
    if (!user || isNaN(pts))
      return message.reply("اكتب: `-addpoints @user عدد_النقاط`");
    addScore(user.id, pts);
    return message.reply(`تم إضافة ${pts} نقطة إلى <@${user.id}>.`);
  }

  if (command === "restart") {
    await message.reply("🔁 جاري إعادة تشغيل البوت...");
    process.exit(0);
  }
}

module.exports = {
  handleOwnerCommand,
};