const { EmbedBuilder } = require("discord.js");
const {
  startLobby,
  showBoard,
} = require("../game/GameManager");
const { getLeaderboardText } = require("../game/leaderboard");

async function handleGameCommand(message, command, args) {
  if (command === "كودنيمز" || command === "codenames") {
    return startLobby(message);
  }

  if (command === "لوحة" || command === "board") {
    return showBoard(message);
  }

  if (command === "صدارة" || command === "top") {
    const lb = getLeaderboardText();
    const embed = new EmbedBuilder()
      .setTitle("🏆 قائمة الصدارة")
      .setDescription(lb)
      .setColor(0xf1c40f);
    return message.channel.send({ embeds: [embed] });
  }
}

module.exports = {
  handleGameCommand,
};