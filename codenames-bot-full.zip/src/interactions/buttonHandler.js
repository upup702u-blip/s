const {
  handleLobbyButton,
  handleWordClick,
  handleViewTeamWords,
  openHintModal,
} = require("../game/GameManager");

async function handleButtonInteraction(interaction) {
  const id = interaction.customId;

  if (id.startsWith("join_") || id === "leave_game") {
    return handleLobbyButton(interaction);
  }

  if (id.startsWith("word_")) {
    return handleWordClick(interaction);
  }

  if (id === "view_blue_words") {
    return handleViewTeamWords(interaction, "BLUE");
  }

  if (id === "view_red_words") {
    return handleViewTeamWords(interaction, "RED");
  }

  if (id === "open_hint_BLUE") {
    return openHintModal(interaction, "BLUE");
  }
  if (id === "open_hint_RED") {
    return openHintModal(interaction, "RED");
  }
}

module.exports = {
  handleButtonInteraction,
};