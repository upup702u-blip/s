const {
  Client,
  GatewayIntentBits,
  Partials,
} = require("discord.js");
const { config, isChannelAllowed } = require("./config");
const { handleGameCommand } = require("./commands/gameCommands");
const { handleOwnerCommand } = require("./commands/ownerCommands");
const { handleButtonInteraction } = require("./interactions/buttonHandler");
const { handleHintModalSubmit } = require("./game/GameManager");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

client.once("ready", () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
});

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!isChannelAllowed(message.channel.id)) return;
  if (!message.content.startsWith(config.prefix)) return;

  const args = message.content.slice(config.prefix.length).trim().split(/\s+/);
  const command = args.shift()?.toLowerCase();

  try {
    await handleGameCommand(message, command, args);
    await handleOwnerCommand(message, command, args, client);
  } catch (e) {
    console.error(e);
    message.reply("حدث خطأ غير متوقع.");
  }
});

client.on("interactionCreate", async (interaction) => {
  if (!isChannelAllowed(interaction.channelId)) return;

  try {
    if (interaction.isButton()) {
      await handleButtonInteraction(interaction);
    } else if (interaction.isModalSubmit()) {
      await handleHintModalSubmit(interaction);
    }
  } catch (e) {
    console.error(e);
    if (!interaction.replied && !interaction.deferred) {
      interaction.reply({
        content: "حدث خطأ أثناء معالجة التفاعل.",
        ephemeral: true,
      });
    }
  }
});

client.login(config.token);