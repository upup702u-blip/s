module.exports = {
  token: "YOUR_TOKEN_HERE", // وضع التوكن النهائي هنا عند التشغيل
  startTime: 15000,
  minPlayers: 6,
  maxPlayers: 20,
  mafiaKillTime: 15000,
  docActionTime: 15000,
  bodyguardPhaseTime: 15000,
  detectorPhaseTime: 15000,
  citizenVoteTime: 20000,
  harlotPhaseTime: 10000,
  assetsPath: "./assets"
};
