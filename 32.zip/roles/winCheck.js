const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const utils = require('../commands/utils');
const config = require('../config');

async function startMafiaPhase(channel, gameState) {
  try {
    if (!gameState.gameActive) return;
    gameState.currentRound = (gameState.currentRound || 0) + 1;
    gameState.mafiaActions = new Map();
    gameState.killedPlayer = null;

    const aliveTargets = gameState.players.filter(p => !gameState.mafias.includes(p));
    if (aliveTargets.length === 0) {
      channel.send('🎉 **فاز الذئاب!**');
      gameState.gameActive = false;
      return;
    }

    // Notify mafia privately with buttons
    const buttons = aliveTargets.map(p => new ButtonBuilder().setCustomId('kill_' + p).setLabel(p).setStyle(ButtonStyle.Danger));
    const rows = createButtonRows(buttons);
    for (const mid of gameState.mafias) {
      try {
        const member = await channel.guild.members.fetch(mid).catch(()=>null);
        if (member) {
          const msg = await member.send({ content: '🐺 حان دور الذئاب لاختيار ضحية', components: rows }).catch(()=>null);
        }
      } catch(e){}
    }

    // schedule a timeout to resolve
    const t = setTimeout(()=>handleMafiaTimeout(channel, gameState), config.mafiaKillTime);
    gameState.timeouts.push(t);
  } catch (e) { console.error('startMafiaPhase', e); }
}

function createButtonRows(buttons) {
  const rows = [];
  for (let i=0; i<buttons.length; i+=5) {
    rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i+5)));
  }
  return rows;
}

async function handleMafiaTimeout(channel, gameState) {
  // if no mafia action, skip to next
  channel.send('⏳ انتهى وقت الذئاب، سيتم المتابعة.');
  // proceed simplified: start next phases (doctor -> votes)
  const t = setTimeout(()=>startVotePhase(channel, gameState), 2000);
  gameState.timeouts.push(t);
}

async function startVotePhase(channel, gameState) {
  try {
    if (!gameState.gameActive) return;
    gameState.votePhaseActive = true;
    const alive = gameState.players.filter(p => p !== gameState.ghost);
    const buttons = alive.map(p => new ButtonBuilder().setCustomId('vote_' + p).setLabel(p).setStyle(ButtonStyle.Secondary));
    buttons.push(new ButtonBuilder().setCustomId('skip_vote').setLabel('تخطي التصويت').setStyle(ButtonStyle.Secondary));
    const rows = createButtonRows(buttons);
    await channel.send({ content: '🗳️ حان وقت التصويت!', components: rows });
    const t = setTimeout(()=>tallyVotes(channel, gameState), config.citizenVoteTime);
    gameState.timeouts.push(t);
  } catch (e) { console.error('startVotePhase', e); }
}

async function handleVote(interaction, gameState) {
  try {
    const parts = interaction.customId.split('_');
    if (parts[0] === 'vote') {
      const target = parts[1];
      if (!gameState.players.includes(interaction.user.id)) return interaction.reply({ content: '❌ أنت لست في اللعبة', ephemeral: true });
      if (!gameState.players.includes(target)) return interaction.reply({ content: '❌ لا يمكن التصويت لهذا', ephemeral: true });
      if (gameState.votes.has(interaction.user.id)) return interaction.reply({ content: '❌ لقد صوتت', ephemeral: true });
      gameState.votes.set(interaction.user.id, target);
      interaction.reply({ content: '✅ تم تسجيل تصويتك', ephemeral: true });
      // if all voted early
      if (gameState.votes.size >= gameState.players.length) {
        if (gameState.voteTimeout) clearTimeout(gameState.voteTimeout);
        await tallyVotes(interaction.channel, gameState);
      }
    } else if (interaction.customId === 'skip_vote') {
      if (!gameState.players.includes(interaction.user.id)) return interaction.reply({ content: '❌ أنت لست في اللعبة', ephemeral: true });
      gameState.votes.set(interaction.user.id, 'skip');
      interaction.reply({ content: '✅ تم تسجيل تخطي', ephemeral: true });
      if (gameState.votes.size >= gameState.players.length) {
        if (gameState.voteTimeout) clearTimeout(gameState.voteTimeout);
        await tallyVotes(interaction.channel, gameState);
      }
    }
  } catch (e) { console.error('handleVote', e); if (!interaction.replied) interaction.reply({ content: 'حدث خطأ', ephemeral: true }); }
}

async function tallyVotes(channel, gameState) {
  try {
    if (!gameState.gameActive) return;
    gameState.votePhaseActive = false;

    if (gameState.votes.size === 0) {
      channel.send('⚠️ لم يتم التصويت، سيتم المتابعة.');
      return;
    }

    const counts = {};
    for (const [voter, target] of gameState.votes.entries()) {
      if (target === 'skip') continue;
      counts[target] = (counts[target] || 0) + 1;
    }

    const max = Math.max(...Object.values(counts || {0:0}));
    const winners = Object.keys(counts).filter(k=>counts[k]===max);

    if (winners.length === 1) {
      const expelled = winners[0];
      gameState.players = gameState.players.filter(p=>p!==expelled);
      channel.send(`⚖️ تم إقصاء <@${expelled}> من اللعبة.`);
    } else {
      channel.send('⚖️ تعادل في الأصوات، لم يتم إقصاء أحد.');
    }

    // reset votes
    gameState.votes = new Map();

    // check win conditions (simplified)
    const done = require('./winCheckSimple').checkWin(channel, gameState);
    if (!done) {
      // loop to next mafia phase pick
      const t = setTimeout(()=>startMafiaPhase(channel, gameState), 3000);
      gameState.timeouts.push(t);
    }
  } catch (e) { console.error('tallyVotes', e); }
}

module.exports = { startMafiaPhase, handleVote, startVotePhase };
