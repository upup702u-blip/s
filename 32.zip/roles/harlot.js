// هذا ملف دور بسيط يعمل كـ placeholder ويحتوي دوال يمكن توسيعها لاحقًا
module.exports = {
  name: "harlot",
  onNight: async (channel, gameState) => {},
  onDeath: async (playerId, channel, gameState) => {}
};
