function checkWin(channel, gameState) {
  try {
    const mafiaCount = gameState.players.filter(p => gameState.playerRoles.get(p) === 'ذئب').length;
    const citizenCount = gameState.players.length - mafiaCount;
    if (mafiaCount === 0) {
      channel.send('🎉 **القرووين فازوا!**');
      return true;
    }
    if (mafiaCount >= citizenCount) {
      channel.send('💀 **فازت الذئاب!**');
      return true;
    }
    return false;
  } catch (e) { console.error('checkWin', e); return false; }
}

module.exports = { checkWin };
