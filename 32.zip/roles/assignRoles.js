const utils = require('../commands/utils');
const config = require('../config');
const fs = require('fs');
const path = require('path');

/**
 * assignRoles(channel, gameState)
 * Assign roles based on number of players and set gameState.playerRoles Map.
 * Keeps original game's concept but splits logic to avoid duplication.
 */
async function assignRoles(channel, gameState) {
  try {
    if (!gameState.gameActive) return;
    // copy players
    gameState.allPlayers = [...gameState.players];
    const players = [...gameState.players].sort(() => Math.random() - 0.5);

    // Determine mafia count by players count (same thresholds as original)
    let mafiaCount = 1;
    if (players.length >= 8) mafiaCount = 2;
    if (players.length >= 15) mafiaCount = 3;
    if (players.length >= 23) mafiaCount = 4;
    if (players.length >= 27) mafiaCount = 6;

    gameState.mafias = players.slice(0, mafiaCount);
    // Assign other special roles deterministically from shuffled list
    const cursor = mafiaCount;
    gameState.doctor = players[cursor] || null;
    gameState.detector = players[cursor+1] || null;
    gameState.bodyguard = players[cursor+2] || null;
    gameState.mayor = players[cursor+3] || null;
    gameState.president = players[cursor+4] || null;
    gameState.princess = players[cursor+5] || null;
    gameState.harlot = players[cursor+6] || null;
    gameState.siren = players[cursor+7] || null;
    gameState.ghost = players[cursor+8] || null;
    gameState.hunter = players[cursor+9] || null;
    gameState.jester = players[cursor+10] || null;
    gameState.townCrier = players[cursor+11] || null;

    // assign plain villagers for the rest
    players.forEach(p => {
      gameState.playerRoles.set(p, 'قروي 👤');
    });
    // assign mafia roles
    gameState.mafias.forEach(m => gameState.playerRoles.set(m, 'ذئب'));

    if (gameState.doctor) gameState.playerRoles.set(gameState.doctor, 'طبيب 🧑‍⚕️');
    if (gameState.detector) gameState.playerRoles.set(gameState.detector, 'المحقق 🕵️‍♂️');
    if (gameState.bodyguard) gameState.playerRoles.set(gameState.bodyguard, 'الحارس 🛡️');
    if (gameState.mayor) gameState.playerRoles.set(gameState.mayor, 'العمدة 👨‍✈️');
    if (gameState.president) gameState.playerRoles.set(gameState.president, 'الملك 👑');
    if (gameState.princess) gameState.playerRoles.set(gameState.princess, 'الاميرة 👸🏼');
    if (gameState.harlot) gameState.playerRoles.set(gameState.harlot, 'المغرية 💋');
    if (gameState.siren) gameState.playerRoles.set(gameState.siren, 'المقموعة');
    if (gameState.hunter) gameState.playerRoles.set(gameState.hunter, 'صياد');
    if (gameState.jester) gameState.playerRoles.set(gameState.jester, 'الجوكر 🃏');
    if (gameState.ghost) gameState.playerRoles.set(gameState.ghost, 'النشبة 🤓');
    if (gameState.townCrier) gameState.playerRoles.set(gameState.townCrier, 'ام زكي 🧕🏻');

    // DM the roles to players (best-effort; interactions not required here)
    for (const playerId of gameState.players) {
      try {
        const user = await channel.guild.members.fetch(playerId).catch(()=>null);
        const role = gameState.playerRoles.get(playerId) || 'قروي 👤';
        if (user && user.user) {
          user.send(`**دورك هو:** **${role.toUpperCase()}**`).catch(()=>{});
        }
      } catch (e) { console.error('dm role', e); }
    }

    await channel.send('🚨 **تم الكشف عن الأدوار لجميع اللاعبين. ستبدأ اللعبة في 5 ثواني.**');
    const t = setTimeout(() => require('./winCheck').startMafiaPhase(channel, gameState), 5000);
    gameState.timeouts.push(t);
  } catch (err) {
    console.error('assignRoles error', err);
    channel.send('❌ حدث خطأ أثناء تعيين الأدوار.');
  }
}

module.exports = { assignRoles };
