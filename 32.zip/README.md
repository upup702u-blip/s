# Werewolf Bot - Organized Project

هذه نسخة مشروع مرتبة لبوت لعبة الذئاب (Mafia/Werewolf)

**ملاحظة مهمة:** التوكن في `config.js` هو `YOUR_TOKEN_HERE` — قم باستبداله بتوكن البوت الفعلي قبل التشغيل.

هيكل المشروع موجود ومُقسّم لسهولة الصيانة.

تشغيل:
1. تركيب الحزم: `npm install discord.js canvas sqlite3`
2. تعديل config.js وowner.json حسب حاجتك
3. تشغيل: `node index.js`

إذا رغبت، أستطيع إرسال شرح تشغيل مفصل أو إضافة أوتوماتيك لصور الأدوار.
