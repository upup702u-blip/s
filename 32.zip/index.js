const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder, ActivityType } = require('discord.js');
const path = require('path');
const fs = require('fs');
const config = require('./config.js');
const owner = require('./owner.json');

// Roles & game logic modules
const assignRoles = require('./roles/assignRoles');
const winCheck = require('./roles/winCheck');
const utils = require('./commands/utils');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers],
});

let gameState = utils.createEmptyGameState();

client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);
  client.user.setActivity({ name: "اللعبة", type: ActivityType.Playing });
});

// Simple permission check
function hasPermission(message) {
  const justice = new Set(["1093714267536109679", "1205181165552803870","520774569855025152","764205712536371232"]);
  const member = message.member;
  return justice.has(message.author.id) || owner.allowedChannels.includes(message.channel.id) || owner.ownerIds.includes(message.author.id) || (member && member.roles && member.roles.cache.some(r => owner.allowedRoleIds.includes(r.id)));
}

client.on('messageCreate', async (message) => {
  try {
    if (message.author.bot) return;
    const content = message.content.trim();

    if (content.startsWith('-الذيب')) {
      if (!hasPermission(message)) return;
      if (gameState.gameActive) return message.channel.send('⚠️ **اللعبة جارية بالفعل.**');
      // start sequence in a modular way
      await require('./commands/startGame')(client, message, gameState);
    }

    if (content.startsWith('-ايقاف')) {
      if (!hasPermission(message)) return;
      if (!gameState.gameActive) return message.channel.send('**لا توجد لعبة لتوقيفها**');
      // stop and reset
      utils.resetGame(gameState);
      return message.channel.send('**تم إيقاف اللعبة**');
    }

    // leaderboard command
    if (content.startsWith('-رتبة')) {
      const rows = await utils.fetchLeaderboardRows();
      return message.channel.send({ content: rows });
    }

  } catch (err) {
    console.error('messageCreate error', err);
    message.channel.send('❌ حدث خطأ غير متوقع.');
  }
});

// Interaction handling (buttons)
client.on('interactionCreate', async (interaction) => {
  try {
    if (!interaction.isButton()) return;
    const customId = interaction.customId;

    // Join / Leave handling (used by startGame flow)
    if (customId === 'join_game') return require('./commands/startGame').handleJoin(interaction, gameState);
    if (customId === 'leave_game') return require('./commands/startGame').handleLeave(interaction, gameState);

    // Delegate to roles or utils for other actions
    if (customId.startsWith('vote_') || customId === 'skip_vote') return require('./roles/winCheck').handleVote(interaction, gameState);
    // provide generic handler fallback
    return interaction.reply({ content: 'تم استقبال التفاعل', ephemeral: true });
  } catch (err) {
    console.error('interactionCreate error', err);
    if (!interaction.replied) await interaction.reply({ content: '❌ حدث خطأ أثناء التفاعل.', ephemeral: true });
  }
});

// Login with placeholder token (user will replace with real token)
client.login(config.token).catch(err => {
  console.warn('تسجيل الدخول فشل: يرجى وضع التوكن في config.js قبل التشغيل.');
});

