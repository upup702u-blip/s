const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.join(__dirname, '..', 'database', 'points.db');
const fs = require('fs');
if (!fs.existsSync(path.dirname(dbPath))) fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) console.error('DB error', err.message);
});

db.run(`CREATE TABLE IF NOT EXISTS points (userId TEXT PRIMARY KEY, points INTEGER)`);

function createEmptyGameState() {
  return {
    players: [],
    allPlayers: [],
    playerRoles: new Map(),
    mafias: [],
    doctor: null,
    detector: null,
    bodyguard: null,
    mayor: null,
    president: null,
    jester: null,
    hunter: null,
    harlot: null,
    ghost: null,
    princess: null,
    siren: null,
    townCrier: null,
    mafiaThread: null,
    gameActive: false,
    gameMessage: null,
    votes: new Map(),
    votePhaseActive: false,
    currentRound: 0,
    killedPlayer: null,
    protectedPlayer: null,
    shieldedPlayer: null,
    playersAbilitiesDisabled: false,
    mafiaActions: new Map(),
    // timeouts tracking for safe cleanup
    timeouts: []
  };
}

function resetGame(state) {
  // clear any timeouts if present
  if (!state) return;
  if (state.timeouts && state.timeouts.length) {
    for (const t of state.timeouts) clearTimeout(t);
  }
  // reset keys
  Object.assign(state, createEmptyGameState());
}

function updatePoints(userId, points) {
  db.run(
    `INSERT INTO points (userId, points) VALUES (?, ?) ON CONFLICT(userId) DO UPDATE SET points = points + ?`,
    [userId, points, points],
    (err) => {
      if (err) console.error('updatePoints error', err.message);
    }
  );
}

function fetchLeaderboardRows() {
  return new Promise((resolve, reject) => {
    db.all(`SELECT userId, points FROM points ORDER BY points DESC LIMIT 10`, (err, rows) => {
      if (err) return reject(err);
      const text = rows.map((r, i) => `${i+1}. <@${r.userId}> — ${r.points} نقاط`).join('\n') || 'لا يوجد بيانات بعد.';
      resolve(text);
    });
  });
}

module.exports = { createEmptyGameState, resetGame, updatePoints, fetchLeaderboardRows };
