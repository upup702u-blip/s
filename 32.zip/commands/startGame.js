const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const path = require('path');
const fs = require('fs');
const config = require('../config');
const assignRoles = require('../roles/assignRoles');
const utils = require('./utils');

let joinMessageMap = new Map(); // messageId -> context

async function start(client, message, gameState) {
  try {
    // reset
    utils.resetGame(gameState);
    gameState.gameActive = true;
    gameState.channel = message.channel;
    gameState.players = [];
    gameState.allPlayers = [];
    gameState.gameMessage = null;

    let timeLeft = Math.floor(config.startTime / 1000);

    // Prepare attachment (placeholder image)
    const imgPath = path.join(__dirname, '..', 'assets', 's2.png');
    const attachment = fs.existsSync(imgPath) ? new AttachmentBuilder(imgPath) : null;

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('join_game').setLabel('دخول').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('leave_game').setLabel('انسحاب').setStyle(ButtonStyle.Secondary)
    );

    const sent = await message.channel.send({
      content: `**@here ستبدأ اللعبه خلال : ${timeLeft} ثواني\nعدد اللاعبين: 0/${config.maxPlayers}**`,
      files: attachment ? [attachment] : [],
      components: [row]
    });

    gameState.gameMessage = sent;

    const interval = setInterval(async () => {
      timeLeft--;
      if (!gameState.gameActive) {
        clearInterval(interval);
        return;
      }
      if (gameState.gameMessage) {
        try {
          await gameState.gameMessage.edit({ content: `**@here ستبدأ اللعبه خلال : ${timeLeft} ثواني\nعدد اللاعبين: ${gameState.players.length}/${config.maxPlayers}**`, components: [row] });
        } catch (e) { console.error('edit message', e); }
      }
      if (timeLeft <= 0) {
        clearInterval(interval);
        // disable buttons
        const disabledRow = new ActionRowBuilder().addComponents(
          row.components.map(b => ButtonBuilder.from(b).setDisabled(true))
        );
        try { await gameState.gameMessage.edit({ content: `@here بدأت اللعبة!\nعدد اللاعبين: ${gameState.players.length}/${config.maxPlayers}`, components: [disabledRow] }); } catch(e) {}
        if (gameState.players.length >= config.minPlayers) {
          await assignRoles.assignRoles(gameState.channel, gameState);
        } else {
          gameState.gameActive = false;
          await message.channel.send('**تم ايقاف اللعبة تحتاج الى 6 اشخاص للبدء**');
          utils.resetGame(gameState);
        }
      }
    }, 1000);

    gameState.timeouts.push(interval);
    return;
  } catch (err) {
    console.error('startGame error', err);
    message.channel.send('❌ حدث خطأ أثناء بدء اللعبة.');
  }
}

// Interaction helpers for join/leave
async function handleJoin(interaction, gameState) {
  try {
    const userId = interaction.user.id;
    if (!gameState.gameActive) return interaction.reply({ content: 'لا توجد لعبة حالية', ephemeral: true });
    if (gameState.players.includes(userId)) return interaction.reply({ content: '❌ أنت بالفعل في اللعبة', ephemeral: true });
    if (gameState.players.length >= require('../config').maxPlayers) return interaction.reply({ content: 'تم الوصول للحد الأقصى', ephemeral: true });
    gameState.players.push(userId);
    if (!gameState.allPlayers.includes(userId)) gameState.allPlayers.push(userId);
    interaction.reply({ content: '✅ انضممت للعبة', ephemeral: true });
    // update message quickly (best-effort)
    try { await gameState.gameMessage.edit({ content: gameState.gameMessage.content.replace(/\d+\/\d+\**/, `${gameState.players.length}/${require('../config').maxPlayers}`) }); } catch(e){}
  } catch (err) {
    console.error('handleJoin error', err);
  }
}

async function handleLeave(interaction, gameState) {
  try {
    const userId = interaction.user.id;
    if (!gameState.gameActive) return interaction.reply({ content: 'لا توجد لعبة حالية', ephemeral: true });
    if (!gameState.players.includes(userId)) return interaction.reply({ content: '❌ أنت لست في اللعبة', ephemeral: true });
    gameState.players = gameState.players.filter(p => p !== userId);
    interaction.reply({ content: '✅ غادرت اللعبة', ephemeral: true });
  } catch (err) {
    console.error('handleLeave error', err);
  }
}

module.exports = start;
module.exports.handleJoin = handleJoin;
module.exports.handleLeave = handleLeave;
